import os

# specify ffmpeg path if not using ubuntu installation
ffmpeg_path = 'ffmpeg'

def convert_video_to_images(input_video_path, output_images_path):
    command = ffmpeg_path + ' -i ' + input_video_path + \
            ' ' + output_images_path + '/thumb%04d.jpg -hide_banner'
    os.system(command)


def image_processing(image):
    pass


def convert_images_to_video(input_images_path, output_video_path):
    command =  ffmpeg_path + ' -f image2 -s 1920x1080 -i ' + \
            input_images_path + '/thumb%04d.jpg -vcodec libx264 -crf 25 \
            -pix_fmt yuv420p ' + output_video_path 
    os.system(command)

def main():
    input_video_path = '/home/e0397123/Desktop/test.mp4'
    output_video_path = '/'.join(input_video_path.split('/')[:-1]) + '/converted.mp4'
    output_images_path = input_video_path.split('.')[0]

    if not os.path.exists(output_images_path):
        os.mkdir(output_images_path)
    convert_video_to_images(input_video_path, output_images_path)
    files = os.listdir(output_images_path)
    for f in files:
        image = os.path.join(output_images_path, f)
        if image.endswith('.jpg'):
            image_processing(image)

    convert_images_to_video(output_images_path, output_video_path)


if __name__=='__main__':
    main()
        

